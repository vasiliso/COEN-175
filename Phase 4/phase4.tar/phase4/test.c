void *f();
void *p;
int main(void){
    p = f;
}